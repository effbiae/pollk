#define Q(z) r(z,P(-1==r,-1))
#include"z.h"//!"#$%&'()*+, -./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`..{|}~  v(n[v|?a])
_u(P_,"-,&/3$%=@A#!2\"+>           *')(.-____:______45____;6______<_?_10"[64>i?i:94>i?2:27])Z0*P=":+-*%&|<>=~.!@?#_^,$LMS...ERZ'/\\()";_u(v,33>i-B)
is(w,wx((92-*s?qs:zs)(i,s)))

F(y,P(!pa,k(13,a,x))Ub=G[24];G[24]=x;r(q(a),u(24,b)))G(z,U z[ua];i(ua,zi=G[i+1];G[i+1]=_i(i,a))x=y(i,x);i(ua,u(i+1,zi))_a(x))G(Z,j(ua,Q(x=aa?y(i,x):z(i,_i(G[9]=ti(j),a),x)))_a(x))
T(n,ij=*s--;65==j?r(e(i,&s),--s):r_(B>j?C[i][j]:G[j%B]?:w0(1,&j)))S(N,x=x?:Q(n(i,&s));v(*s)?x:N(i,&s,y(Q(n(i,&s)),x)))
S(K,ij=*s--%B;k(j,29>j&v(*s)?0:v(*s)?*s---B:Q(N(i,&s,0)),x))S(Y,ij=*s--;ih=*s---96;Qz(26<h||B<(h=G[h])-1)(61<j?Z:z)(h,Q(N(i,&s,0)),x))
S(A,ih=v(*--s)?*s--%B:0;ij='i'==*s&&B>_s-96u;s-=j;U*a=G+*s--%B;a=j?x(*a,P(tx,0)xU+(i2)G[9]):a;N(i,&s,r_(*a=h?k(h,*a,x):(_r(*a),x))))
S(E,64==*s?x:E(i,&s,Q((B==*s?A:3>*s-61u>v(s[-2])?Y:K)(i,&s,x))))T(e,E(i,&s,Q(N(i,&s,0))))_u(q,ss=F[i];s+=1+*s;Ux=Q(e(i,&s));B==s[2+(31u>s[2]-33)]?_x(0):x)

is(zs,$5(id(s[1],"\\ltwv"),_k(0),ls(s+3),i=ic(B,s);si=0;ts(2<i?qs(i-2,s+2):1,s+i+1),k_(0,0),vf(5>$)))is(ts,if(92-*s)p(0,s);Uu=nt()+8*i;i(i,Q(_r(92-*s?q(0):zs(0,s))))_p(0);ti(.5+(nt()-u)/1e6))
ss;s(ls,ii=fs(s);Qs(!i,s)Ux=ms(i,s);s=(i0*)x;L(10,in=0;W(++n<i&&'/ '-*(i1*)(s+n));W(B==s[n-1])--n;i(n,bi=si)b[n]=0;47==*b?1:w(n,b))_m(x,i);0)int main(int i,i0**_){k_(0,0);
//G[1]=ns(5,"1 2 3");
if(s)o(s);$(*++_,ls(*_))ws(L);W(i=_w(wc(B),b,256))if(--i)(bi=0,w(i,b));}

//print
inx($m,sd=b;j(l(n?192/n:18,vx),ih=mx?i*vx+j:j;d+=n?js(n-1,3>tx?x2[h]:.5+100*xe[h],d):(3>tx?$i:$e)(x2[h],d);*d++=B)--d-b)s($p,i(*s,ij=s[i+2];bi=B>j?48:96>j?P[j-B]:j)*s)
f(wm,ij=2>tx-2?r(0,i(nx,r=m(r,x2[i]))):0;j=127>j>>23?3>tx?1+li(j):0:0;i(mx?l(5,mx):1,wl($m(i,j,x)))if(3<mx)ws("..");0)
f(wx,if(1<1+x)ax?wl(px?B>G[px]?$p(F[x]):(*b=P[x],1):(3>tx?$i:$e)(ix,b)):_x(!nx?0:1==tx&B<=*sx?w0(nx,sx):tx?wm(x):ws("lst"));x)ins(t$,t(i,(3>i?i$:e$)(n,s)))
//parse
Z0*f,l;ins(vs,im=nc(n,B,s);m?R(i,m+1,sd=s+n;j(nr,r2[j]=t$(i,n=l(d-s,id(B,s)),s);s+=n+1)):t$(i,n,s))is(qs,Ux=0;L(59,x=_x('::'==*(i1*)(s+1)?(p(*s%B,s+3),0):r(q(p(0,s)),_p(0))))x)
ijs(cs,Va=Vs;Vb=46==a|10>a-48;in=ib($4(j,34!=a,27>a-96|b,b,b|d1(s)|2>a-45&d1(s-1)));C[i][*++f=l++]=$4(j,1==n?t(1,*s):ns(n,s),0,R(2,n,i(n,r2[i]=a[i]-48)),vs(n>ib(46!=a&101!=a)?3:2,n,s));n)
is(p,sd=f=F+i;*++f=64;l=0;ij;W(j=*s;B<j&59!=j)s+=8>(j=34==j?0:96==j?1:48==j&10u>s[1]-48?2:10u>s[2>j-45&v(*f)]-48?3:26>j-97?j:P_(j-B))?cs(i,j,s+!j)+2*!j:95!=(*++f=j);f[1]=0;*d=f-d-1;u(i,i))


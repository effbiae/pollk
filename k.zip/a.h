#define U(n,z)    _x(R(0,n,UR=sr;j(n,R_=_(z))))
#define X(z) r(uz(x),VX=sx;VR=sr;J(Nx,R_=_(z)))
#define EE {a=E(a);x=E(x);}
#define sx ((i0*)_+(~63&ox))
#include"_.h"
#define o(f) __builtin_ia32_##f##512 
UV(b0,o(cvtb2mask)(x))UV(b2,o(cvtd2mask)(x))Vg(S4,$4(i,o(alignd)(x,z0,15),o(alignd)(x,z0,14),o(alignd)(x,z0,12),o(alignd)(x,z0,8)))Ve(_q,o(sqrtps)(x,4))VF(MI,o(pmaxud)(a,x))
#define e(z) _l(1.442695f*(z)) //.69314718 a*x%1+E-x erz x%%xx%n x%Sx:Ex-Mx
j6 P={-1},R={0xc6a4a7935bd1e995};_D(j6,_P,R^=P;P=(P<<55|P>>9)^R^R<<14;R=R<<37|R>>27;P+R)_Z(P_,i(8,P[i]=_P()[0])i(1e4,_P()))Ze eS(e6);VF(SI,(i6)a+x)
ZV _[1<<24];Z2 O[1<<8],o;ZU uz(U),mi(U),b[]={3,0,2,2},W;_g(hn,x<<=bi;64<x?ju(x-1)-6:0)_g(m_,(U)i<<32|x)f(_m,~(b(16)<<32)&x)_f(P0,if(Nx%64)xV[Nx>>6]&=(i0)(Nx%64)>I0;x)
#define p6(a,b,c,d,e,f) (a+x*(b+x*(c+x*(d+x*(e+x*f))))) //unroll4? rsqrt[14|28]ps
Ve(l_,Sz=x;x=127<<23|(1<<23)-1&z;C(e6,(z>>23)-127)+(x-1)*p6(3.1157899f,-3.324199f,2.5988452f,-1.2315303f,.31821337f,-.034436006f))
Ve(_l,Ez=C(e6,C(s6,x-.5));x-=z;(1+z)*p6(.99999994f,.69315308f,.24015361f,.055826318f,.0089893397f,.0018775767f))
_e(se,in=n4(nx);EX=sx;Ez[4]={};i(n/4,i(4,zi+=X_))Eb=z[3];i(3,b+=zi)i(n%4,b+=X_)eS(b),Ux)_e(sE,in=n4(nx);EX=sx;Ez[4]={};i(n/4,i(4,zi+=A_*X_))Eb=z[3];i(3,b+=zi)i(n%4,b+=A_*X_)eS(b),EA,Ux)
_Z(vm,i(n/4,Ez[4]={};     EX=x;h(m,i(4,zi+=X_*a[h])     X+=n-4)i(4,R_=zi)      x+=4)i(n%4,Ez={};     EX=x;h(m,z+=*X*a[h];   X+=n)R_=z;      ++x),im,in,VR,e2*a,e6*x)
_Z(mm,i(n/4,Ez[4]={};EA=a;EX=x;h(m,i(4,zi+=X_*A_)A+=n-4;X+=n-4)i(4,R_=zi)a+=64;x+=4)i(n%4,Ez={};EA=a;EX=x;h(m,z+=*X**A;A+=n;X+=n)R_=z;a+=16;++x),im,in,VR,e2*a,e6*x)
_G(e3,P(a,X(Eb=Ex;aE[j]*b/(1+e(-b))))P(!i--,X(e(Ex)))ee=1/(i?(e=ei(mi(x)),se(x=X(e(Ex-e)))):_q(sE(sx,x)/nx-ze)[0]);X(e*Ex))
#define on(f,O,t,T) _D(t##6,f##T,i(4,a=O##T(a,S4(i,a)))a,Va)_f(f##t,VX=sx;Va={};j(n4(nx),a=O##T(a,X_))f##T(a)[15])_f(O##t,t##6 a={};X(a=f##T(*X)+a[15]))
on(m,M,i,I)on(s,S,i,I)g(o3,_x(!i--?0:i&2<tx?te(se(x)):t(tx,(i?si:mi)(x))))g(s3,!i--?0:(i?Si:Mi)(x))_e(eS,i(4,z+=(e6)S4(i,(V)z))z[15],Ez)
